var http = require('http');
var fs = require('fs');

http.createServer(function (req, response) {
  var request = req.url.replace('/', '')
  console.log(request)
  if(request == ''){
    request = 'index.html';
  }
  fs.readFile(request, function (err, data) {
        if (err) {
            console.log(err);
            response.writeHead(404, {'Content-Type': 'text/html'});
        } else {
            response.writeHead(200, {'Content-Type': 'text/html'});
            response.write(data.toString());
        }
        response.end();
    });
}).listen(8080); 
console.log('Server running at http://127.0.0.1:8080/\n')
