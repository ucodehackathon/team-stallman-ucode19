from pymongo import MongoClient
import json
from bson import ObjectId
#:pprint library is used to make the output look more pretty

from pprint import pprint as pp
from flask import Flask
from flask_restful import Api, Resource, reqparse
from flask_cors import CORS, cross_origin

app = Flask(__name__)
api = Api(app)

cors = CORS(app)
app.config['CORS_HEADERS'] = 'Content-Type'


class JSONEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, ObjectId):
            return str(o)
        return json.JSONEncoder.default(self, o)

client = MongoClient(port=27017)
db = client.AdidasDB

parameters = ["age", "weight", "height", "number", "position", "feet_size", "sensor"]

class User(Resource):
    @app.route("/")
    @cross_origin()
    def get(self, name):
        """
        Return the requested user information.
        :param name: name of database
        :return:
        """
        if name == 'all':
            cursor = db.Players.find({})
            users = []
            for document in cursor:
                users.append(document)

            users = JSONEncoder().encode(users)
            #users = json.JSONDecoder().decode(users)
            return users, 200

        response = db.Players.find_one({"name": name})

        if response is None:
            return "Player not found", 400
        print(response)
        response_encoded = JSONEncoder().encode(response)
        response_decoded = json.JSONDecoder().decode(response_encoded)
        return response_decoded, 200

    @cross_origin()
    def post(self, name):
        """
        Add a user to the database, if exists, raise error Example: $curl
        http://localhost:5000/user/Dimas_Avila_Martinez -d "age=20&weight=81&height=180&number=5&position=goal_keeper&feet_size=42"  -X POST
        :param name: name of
        database :return:
        """
        p = db.Players.find_one({"name": name})
        if p is not None:
            return "User with name {} already exists".format(name), 400
        parser = reqparse.RequestParser()

        for parameter in parameters:
            parser.add_argument(parameter)
        args = parser.parse_args()

        player = {"name": name}
        for param in parameters:
            player[param] = args[param]

        db.Players.insert_one(player)
        return name, 201

    def put(self, name):
        """
        Updates a user and if does not exists, creates one.
        Example: $curl http://localhost:5000/user/Mike
        :param name: name of database
        :return:

        parser = reqparse.RequestParser()
        parser.add_argument("age")
        parser.add_argument("occupation")
        args = parser.parse_args()

        for user in users:
            if (name == user["name"]):
                user["age"] = args["age"]
                user["occupation"] = args["occupation"]
                return user, 200

        user = {
            "name": name,
            "age": args["age"],
            "occupation": args["occupation"]
        }
        users.append(user)"""
        return "not implemented", 201

    def delete(self, name):
        """
        Removes a user from the database
        Example: curl http://localhost:5000/user/Milo  -X DELETE
        :param name: name of database
        :return:
        """
        global users
        users = [user for user in users if user["name"] != name]
        return "{} is deleted.".format(name), 200


api.add_resource(User, "/user/<string:name>")

app.run(debug=True)
