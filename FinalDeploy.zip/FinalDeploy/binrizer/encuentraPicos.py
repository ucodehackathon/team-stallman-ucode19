#!/usr/bin/python3
import sys
import csv
import math

# def encuentraPicos(self):
maxAbs = 0
pos = 0
var = 0
m = 0
modulo = []
r = 0
count = 0
count2 = 0
with open(sys.argv[1], newline='') as csvfile:
    filitas = csv.reader(csvfile, delimiter=',', quotechar=',')
    for index, row in enumerate(filitas):
        modulo.append(math.sqrt(float(row[1]) ** 2 + float(row[2]) ** 2 + float(row[3]) ** 2))
    media = sum(modulo) / len(modulo)
    for j in modulo:
        var += (j - media) ** 2
    else:
        dest = math.sqrt(var / len(modulo))
    #print([media, dest])
    max_init = []
    max_end = []
    for i in range(len(modulo)):
        if (modulo[i] > media + 2 * dest):
            aux = modulo[i:i + 3 * 500]
            while count < 3:
                max_l = aux.index(max(aux)) + i
                for number in max_init:
                    if number - 10 < 0:
                        pass
                max_init.append(max_l)
                count += 1
                #print(max_l)
                aux.remove(aux[max_l - i])
            break

    for x in range(len(modulo) - 1, 0, -1):
        if (modulo[x] > media + 2 * dest):
            aux = modulo[x - 3 * 500:x]
            while count2 < 3:
                max_l = aux.index(max(aux)) + x
                for number in max_end:
                    if (number - 10 < 0):
                        pass
                max_end.append(max_l)
                count2 += 1
                #print(max_l)
                aux.remove(aux[max_l - x])
            break
    indiceValor = [max(max_init), max(max_end)]
    print(indiceValor[0], end=" ")
    print(indiceValor[1], end=" ")
