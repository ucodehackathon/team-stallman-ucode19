#!/bin/bash
ffmpeg -i $1.mp4 %d.png -hide_banner
number="$(ls *.png -l | wc -l)"

#for i in {1..$number}
#do
   #convert -monochrome $i.png $i.bmp
#done

for ((i = 1; i <= number; i++)); do
	echo $i
	convert -monochrome $i.png $i.bmp
done
python tester.py $number $2 > ../Web_Server/logs/log$4.txt
python3 encuentraPicos.py $3 >> ../Web_Server/logs/log$4.txt
