from __future__ import print_function
import sys
import cv2 as cv
import numpy as np
from matplotlib import pyplot as plt


def video_seconds(num, fps):
    min_init = 10
    min_end = 10

    for i in range(2*fps+1):
        #print((str(i + 1) + ".png"))
        img = cv.imread((str(i + 1) + ".png"), 0)
        img2 = img.copy()
        template = cv.imread('template_bin.jpeg', 0)
        w, h = template.shape[::-1]
        # All the 6 methods for comparison in a list
        # methods = ['cv.TM_CCOEFF', 'cv.TM_CCOEFF_NORMED', 'cv.TM_CCORR',
        #            'cv.TM_CCORR_NORMED', 'cv.TM_SQDIFF', 'cv.TM_SQDIFF_NORMED']
        methods = ['cv.TM_CCORR_NORMED']
        for meth in methods:
            img = img2.copy()
            method = eval(meth)
            # Apply template Matching
            res = cv.matchTemplate(img, template, method)
            min_val, max_val, min_loc, max_loc = cv.minMaxLoc(res)


            if min_init > min_val:
                index_min_init = i
                min_init = min_val

    for i in range(num- (2 * fps), num):
        #print((str(i + 1) + ".png"))
        img = cv.imread((str(i + 1) + ".png"), 0)
        img2 = img.copy()
        template = cv.imread('template_bin.jpeg', 0)
        w, h = template.shape[::-1]
        # All the 6 methods for comparison in a list
        # methods = ['cv.TM_CCOEFF', 'cv.TM_CCOEFF_NORMED', 'cv.TM_CCORR',
        #            'cv.TM_CCORR_NORMED', 'cv.TM_SQDIFF', 'cv.TM_SQDIFF_NORMED']
        methods = ['cv.TM_CCORR_NORMED']
        for meth in methods:
            img = img2.copy()
            method = eval(meth)
            # Apply template Matching
            res = cv.matchTemplate(img, template, method)
            min_val, max_val, min_loc, max_loc = cv.minMaxLoc(res)


            if min_end > min_val:
                index_min_end = i
                min_end = min_val

    return [index_min_init/fps, index_min_end/fps]


timestamps = video_seconds(int(sys.argv[1]), int(sys.argv[2]))
print(timestamps[0], end=" ")
print(timestamps[1], end=" ")
