# Sync Script for Adidas Sensor

`$ pip3 install -r requirements.txt`

Modify `sync.py` to set the correct file to use and sampling rate.

`$ python3 sync.py`

From the cli:

`$ adidas-sync-video [csv_file] [first_peak] [last_peak] [first_second_video] [last_second_video] [sampling_rate]`
